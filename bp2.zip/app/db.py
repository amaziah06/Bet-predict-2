"""Tiny database layer: Postgres when DATABASE_URL is set (persistent), otherwise a local SQLite file.
Free web hosts wipe local files on restart, so SQLite there means accounts are lost."""
import os
import sqlite3
from contextlib import contextmanager

from .config import DATABASE_URL, DATA_DIR

PG = DATABASE_URL.startswith("postgresql://")
WARNING = None
if PG:
    try:
        import psycopg2
        INTEGRITY_ERRORS = (psycopg2.IntegrityError,)
    except ImportError:  # requirements not installed: fall back instead of crashing
        PG = False
        WARNING = "psycopg2 is not installed, so DATABASE_URL is ignored and accounts are NOT saved permanently."
if not PG:
    INTEGRITY_ERRORS = (sqlite3.IntegrityError,)
    if WARNING is None and os.getenv("RENDER"):
        WARNING = ("No DATABASE_URL set: accounts are stored in a temporary file and will be lost "
                   "whenever the server restarts.")

SQLITE_PATH = DATA_DIR / "users.db"


@contextmanager
def connect():
    if PG:
        conn = psycopg2.connect(DATABASE_URL, connect_timeout=10)
    else:
        conn = sqlite3.connect(SQLITE_PATH, timeout=10)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def run(conn, sql, params=()):
    """Execute with '?' placeholders on both backends."""
    cur = conn.cursor()
    cur.execute(sql.replace("?", "%s") if PG else sql, params)
    return cur


def init():
    pk = "SERIAL PRIMARY KEY" if PG else "INTEGER PRIMARY KEY AUTOINCREMENT"
    with connect() as c:
        run(c, f"CREATE TABLE IF NOT EXISTS users (id {pk}, email TEXT UNIQUE NOT NULL, "
               "pw_hash TEXT NOT NULL, created_at BIGINT NOT NULL)")
        run(c, "CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY, "
               "user_id INTEGER NOT NULL, expires_at BIGINT NOT NULL)")
        run(c, "CREATE INDEX IF NOT EXISTS sessions_user ON sessions(user_id)")


def kind():
    return "postgres" if PG else "sqlite"
