const $=s=>document.querySelector(s);
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const pct=x=>(x*100).toFixed(1)+'%';
function localDate(){const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');}
function addDays(iso,n){const d=new Date(iso+'T12:00:00');d.setDate(d.getDate()+n);return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');}
async function api(path,opts){
  const r=await fetch(path,Object.assign({credentials:'same-origin',headers:{'Content-Type':'application/json'}},opts||{}));
  if(r.status===401){location.href='/login';throw new Error('Please log in.');}
  const t=await r.text();let j=null;try{j=JSON.parse(t)}catch(e){}
  if(!r.ok){let d=j&&j.detail;if(Array.isArray(d))d='Please check what you typed.';throw new Error(d||('Server error '+r.status));}
  return j;
}
async function logout(){try{await fetch('/api/logout',{method:'POST',credentials:'same-origin'})}catch(e){}location.href='/login';}
async function mountNav(active){
  $('#top').innerHTML=`<div class="nav"><b>⚽ BetPredict</b>
    <a href="/games" class="${active==='games'?'active':''}">All games</a>
    <a href="/surest" class="${active==='surest'?'active':''}">Surest picks</a>
    <span class="sp"></span><span class="mut small" id="who"></span><button onclick="logout()">Log out</button></div>`;
  const me=await api('/api/me');$('#who').textContent=me.email;return me;
}
function clockTime(iso){try{return new Date(iso).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}catch(e){return ''}}
