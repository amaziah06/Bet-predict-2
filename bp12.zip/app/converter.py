"""Booking-code converter.

Honest status: bookmakers have no public API for booking codes. Reading a code from SportyBet uses its public
share link; every other bookmaker is reached by PASTING what the bookmaker's own page returns (or, later, a
tested adapter). Nothing here has been verified against the live sites from the build machine (it is blocked),
so the page shows exactly what was read and what could not be matched."""
import json
import re

import requests

BOOKS = {
    "sportybet": "SportyBet", "paripesa": "Paripesa", "1xbet": "1xBet", "footballcom": "Football.com",
    "1win": "1win", "betnaija": "Bet Naija", "betking": "BetKing",
}
# which bookmakers can be READ by code from the server (others: paste mode only)
FETCHABLE = {"sportybet"}

# how each bet is worded on the target bookmakers (same wording used by all of them for these common bets)
def label(market, key, home, away):
    if market == "1X2":
        return {"Home": f"{home} to win (1)", "Draw": "Draw (X)", "Away": f"{away} to win (2)"}[key]
    if market == "Double chance":
        return {"1X": "Double chance: Home or Draw (1X)", "X2": "Double chance: Draw or Away (X2)",
                "12": "Double chance: Home or Away (12)"}[key]
    if market == "DNB":
        return {"Home": f"Draw no bet: {home}", "Away": f"Draw no bet: {away}"}[key]
    if market in ("Goals", "1H goals", "2H goals"):
        side, line = key.split()
        where = {"Goals": "Total goals", "1H goals": "1st half total goals", "2H goals": "2nd half total goals"}[market]
        refund = f" (stake back if exactly {line})" if "." not in line else ""
        return f"{where} {side} {line}{refund}"
    if market == "BTTS":
        return f"Both teams to score (GG/NG): {'GG (Yes)' if key == 'Yes' else 'NG (No)'}"
    return key


class ConvertError(Exception):
    pass


def clean_code(code):
    code = (code or "").strip()
    if not re.fullmatch(r"[A-Za-z0-9]{4,14}", code):
        raise ConvertError("That does not look like a booking code (letters and numbers only).")
    return code


def fetch_sportybet(code):
    code = clean_code(code)
    try:
        r = requests.get(f"https://www.sportybet.com/api/ng/orders/share/{code}", timeout=15,
                         headers={"User-Agent": "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile",
                                  "Accept": "application/json", "clientid": "web", "operid": "2", "platform": "web"})
    except requests.RequestException:
        raise ConvertError("Could not reach SportyBet from the server (it may block it). Use paste mode: open the "
                           "link shown below in your phone browser, copy everything and paste it here.")
    if r.status_code != 200:
        raise ConvertError(f"SportyBet answered {r.status_code}. The server may be blocked: use paste mode.")
    return r.text


def _kick(ms):
    """SportyBet gives the start time as epoch milliseconds."""
    try:
        from datetime import datetime, timezone
        from .config import tzinfo
        d = datetime.fromtimestamp(int(ms) / 1000, tz=timezone.utc).astimezone(tzinfo())
        return d.strftime("%a %d %b, %H:%M")
    except Exception:
        return None


def _num(x):
    try:
        return float(x)
    except Exception:
        return None


def _market_from(mid, desc, odesc, spec):
    """Map a bookmaker market/outcome to (market, key). Text is used first (it is what the bookmaker shows)."""
    d, o = (desc or "").lower(), (odesc or "").lower().strip()
    mid = str(mid or "")
    line = None
    m = re.search(r"total\s*=?\s*([0-9.]+)", spec or "")
    if m:
        line = m.group(1)
    m2 = re.search(r"([0-9]+(?:\.[0-9]+)?)", o)
    if m2 and not line:
        line = m2.group(1)
    if d.strip() in ("1x2", "match result", "full time result") or mid == "1":
        k = {"home": "Home", "1": "Home", "draw": "Draw", "x": "Draw", "away": "Away", "2": "Away"}.get(o)
        return ("1X2", k) if k else None
    if "double chance" in d or mid == "10":
        s = o.replace(" ", "")
        k = {"homeordraw": "1X", "1x": "1X", "draworaway": "X2", "x2": "X2", "homeoraway": "12", "12": "12"}.get(s)
        return ("Double chance", k) if k else None
    if "draw no bet" in d or mid == "11":
        k = {"home": "Home", "1": "Home", "away": "Away", "2": "Away"}.get(o)
        return ("DNB", k) if k else None
    side = "Over" if o.startswith("over") else "Under" if o.startswith("under") else None
    if "half" in d and ("over/under" in d or "total" in d) and not any(w in d for w in ("team", "corner", "booking", "card")):
        half = "2H" if ("2nd" in d or "second" in d) else "1H"   # plain "Half - Over/Under" is the 1st half
        if side and line:
            return (half + " goals", f"{side} {line}")
        return None
    if ("over/under" in d or "total" in d or mid == "18") and not any(w in d for w in ("team", "corner", "booking", "card", "half")):
        if side and line:
            return ("Goals", f"{side} {line}")
        return None
    if "gg/ng" in d or "both teams to score" in d or mid == "29":
        if "half" in d or "&" in d:
            return None
        k = {"yes": "Yes", "gg": "Yes", "no": "No", "ng": "No"}.get(o)
        return ("BTTS", k) if k else None
    return None


def _xml_obj(el):
    kids = list(el)
    if not kids:
        return (el.text or "").strip() or None
    if all(k.tag == el.tag for k in kids):  # SportyBet wraps lists as <outcomes><outcomes>..</outcomes></outcomes>
        return _Multi(_xml_obj(k) for k in kids)
    out = {}
    for k in kids:
        v = _xml_obj(k)
        if k.tag in out:
            if not isinstance(out[k.tag], list) or not getattr(out[k.tag], "_multi", False):
                out[k.tag] = _Multi([out[k.tag]])
            out[k.tag].append(v)
        else:
            out[k.tag] = v
    return out


class _Multi(list):
    _multi = True


def _aslist(x):
    return x if isinstance(x, list) else ([] if x is None else [x])


def _to_obj(text):
    t = (text or "").strip()
    if t.startswith("<"):
        import xml.etree.ElementTree as ET
        try:
            root = ET.fromstring(t)
        except Exception:
            raise ConvertError("That text is not complete. Select ALL the text on the SportyBet page and paste it.")
        return _xml_obj(root)
    try:
        return json.loads(t)
    except Exception:
        raise ConvertError("That is not the text from the SportyBet link. Select ALL the text on the page and paste it.")


def parse_sportybet(text):
    """Read SportyBet's share response (JSON or XML). Returns (selections, unmatched)."""
    j = _to_obj(text)
    data = j.get("data") if isinstance(j, dict) else None
    if not isinstance(data, dict):
        msg = (j.get("message") or j.get("innerMsg")) if isinstance(j, dict) else None
        raise ConvertError(f"SportyBet answered: \"{msg or 'no data'}\". Make a fresh code and try again "
                           "(codes expire, and a code made for another country will not work).")
    sels, bad = [], []
    for ev in _aslist(data.get("outcomes")):
        home, away = ev.get("homeTeamName"), ev.get("awayTeamName")
        for mk in _aslist(ev.get("markets")):
            for oc in _aslist(mk.get("outcomes")):
                mapped = _market_from(mk.get("id"), mk.get("desc"), oc.get("desc"), mk.get("specifier"))
                row = {"home": home, "away": away, "odds": _num(oc.get("odds")), "league": (ev.get("sport") or {}).get(
                    "category", {}).get("tournament", {}).get("name"), "kickoff": _kick(ev.get("estimateStartTime")),
                       "source_market": f"{mk.get('desc')} {mk.get('specifier') or ''}".strip(),
                       "source_pick": oc.get("desc")}
                if mapped:
                    sels.append({**row, "market": mapped[0], "key": mapped[1]})
                else:
                    bad.append(row)
    if not sels and not bad:
        raise ConvertError("No games were found in that code. It may have expired.")
    return sels, bad


def read_code(book, code=None, pasted=None):
    if book == "sportybet":
        text = pasted if pasted else fetch_sportybet(code)
        return parse_sportybet(text)
    raise ConvertError(f"Reading {BOOKS[book]} codes is not connected yet. It needs a real sample of what "
                       f"{BOOKS[book]} returns for a code: send me one (see the help on this page).")


def convert(src, dst, code=None, pasted=None):
    if src not in BOOKS or dst not in BOOKS:
        raise ConvertError("Unknown bookmaker.")
    sels, bad = read_code(src, code, pasted)
    out = []
    for s in sels:
        out.append({**s, "target_label": label(s["market"], s["key"], s["home"], s["away"])})
    lines = [f"{i + 1}. {s['home']} vs {s['away']}" + (f" ({s['kickoff']})" if s.get("kickoff") else "")
             + f" - {s['target_label']}" + (f" @ {s['odds']}" if s["odds"] else "")
             for i, s in enumerate(out)]
    return {"source": BOOKS[src], "target": BOOKS[dst], "selections": out, "unmatched": bad, "text": "\n".join(lines),
            "target_code": None,
            "note": (f"Creating a {BOOKS[dst]} code automatically is not connected yet, so use the list above to "
                     f"build the slip in {BOOKS[dst]} (the wording matches its menus).")}
